module.exports = {
    //...
    resolve: {
        extensions: [".js", ".json", ".ts", ".tsx", ".jsx"],
    },
  };